"""
Vercel Serverless Function Entry Point for Smart Quiz Flask Application.
Routes incoming HTTP requests directly to the Flask WSGI instance.
"""

import os
import sys

# Ensure project root directory is in sys.path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from app import app

# Vercel Serverless WSGI entry point
# Vercel looks for 'app' in this file
if __name__ == "__main__":
    app.run()
